import { scrapeChat } from './lib/scrape.js';
import { streamChat, PROVIDERS, DEFAULT_SETTINGS, SEARCH_SUPPORTED, hasCredential, connectedProviders } from './lib/providers.js';
import { renderMarkdown, plainText } from './lib/markdown.js';
import { signInWithOpenRouter, listModels, pickDefaultModel } from './lib/auth.js';

const PRESETS = {
  explain: { label: 'Explain concisely', prompt: 'Explain this concisely.' },
};

const $ = (id) => document.getElementById(id);
const el = (tag, attrs = {}, ...kids) => {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v === undefined || v === null || v === false) continue;
    if (k === 'class') e.className = v;
    else if (k === 'html') e.innerHTML = v;
    else if (k === 'value') e.value = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else e.setAttribute(k, v === true ? '' : v);
  }
  for (const kid of kids.flat()) if (kid != null && kid !== false) e.append(kid);
  return e;
};
const short = (s, n = 48) => { s = String(s || '').replace(/\s+/g, ' ').trim(); return s.length > n ? s.slice(0, n - 1) + '…' : s; };
const uid = () => crypto.randomUUID().slice(0, 8);
const nodeCount = (t) => (t && t.nodes ? Object.keys(t.nodes).length : 0);
const ago = (ts) => {
  const s = Math.round((Date.now() - ts) / 1000);
  if (s < 60) return 'just now';
  if (s < 3600) return `${Math.round(s / 60)} min ago`;
  if (s < 86400) return `${Math.round(s / 3600)} h ago`;
  return new Date(ts).toLocaleDateString();
};
const siteFromUrl = (u) => {
  try {
    const h = new URL(u).hostname;
    if (/(^|\.)claude\.ai$/.test(h)) return 'Claude';
    if (/(^|\.)chatgpt\.com$|(^|\.)chat\.openai\.com$/.test(h)) return 'ChatGPT';
    if (/(^|\.)gemini\.google\.com$/.test(h)) return 'Gemini';
  } catch { /* not a URL */ }
  return '';
};
const cleanTitle = (t) => String(t || '').replace(/\s*[-–—|]\s*(Google Gemini|Gemini|Claude|ChatGPT)\s*$/i, '').trim();
const KEY_HINT = { anthropic: 'sk-ant-api03-', openai: 'sk-', openrouter: 'sk-or-', gemini: 'AIza' };

/** Catch keys that are obviously wrong before asking the provider. Returns a message, or '' if it looks fine. */
function keyFormatProblem(p, key) {
  if (p === 'anthropic') {
    if (key.startsWith('sk-ant-admin')) return 'That’s an Admin key. Create a regular API key instead (it starts with sk-ant-api03-).';
    if (!key.startsWith('sk-ant-')) return 'Claude keys start with sk-ant-api03-. Make sure you copied the key itself, not its name or ID.';
  }
  if (p === 'openai' && !key.startsWith('sk-')) return 'OpenAI keys start with sk-. Make sure you copied the whole key.';
  if (p === 'gemini' && !key.startsWith('AIza')) return 'Gemini keys start with AIza. Make sure you copied the whole key.';
  return '';
}

/** Turn an API error into one plain sentence that says what to do. */
function friendlyError(p, e) {
  const name = (PROVIDERS[p] && PROVIDERS[p].short) || 'The AI';
  const msg = String((e && e.message) || e || '');
  const st = e && e.status;
  const model = state.settings.models[p];
  if ((e && e.name === 'TypeError') || /failed to fetch|networkerror|load failed/i.test(msg)) {
    return p === 'compatible'
      ? `Couldn’t reach your server at ${state.settings.baseUrl}. Make sure it’s running.`
      : `Couldn’t reach ${name}. Check your internet connection and try again.`;
  }
  if (st === 401 || (st === 403 && /key|auth|credential|permission/i.test(msg))) {
    const hint = KEY_HINT[p];
    return `That ${name} key didn’t work. Make sure you copied the whole key${hint ? `, starting with ${hint}` : ''}.`;
  }
  if (st === 402 || /credit balance|insufficient_quota|insufficient credits|billing|exceeded your current quota/i.test(msg)) {
    return `Your ${name} account is out of credits. Add funds on ${name}’s billing page, then try again.`;
  }
  if (/web search.*(not enabled|disabled)|search.*not (available|supported)/i.test(msg)) {
    return `Web search isn’t available on your ${name} account. Turn off Search and try again.`;
  }
  if (st === 429) return `${name} is limiting requests right now. Wait a minute and try again.`;
  if (st === 404 || /model.*(not found|does not exist|not supported)|not_found_error/i.test(msg)) {
    return `The model “${model}” isn’t available on your ${name} account. Pick another under Account → Model.`;
  }
  if (st === 413 || /too long|context length|maximum context|too many tokens/i.test(msg)) {
    return 'This branch is too long for the model. Start a new branch, or turn off “Remember the original chat” in Account.';
  }
  if (st === 400 && /image/i.test(msg)) return `${name} couldn’t read that image. Try a different image or model.`;
  if (st === 529 || (st >= 500 && st < 600)) return `${name} is having trouble right now. Try again in a moment.`;
  return `${name} returned an error: ${msg.replace(/^\d{3}[^:]*:\s*/, '')}`;
}

const maskKey = (k) => (k ? '••••' + k.slice(-4) : '');

const state = {
  windowId: null,
  tab: null,
  key: null,
  tree: null,
  current: 'root',
  draft: null,       // { parentId, anchor }
  streaming: null,   // { tree, nodeId, text, controller }
  settings: structuredClone(DEFAULT_SETTINGS),
  account: null,     // { name, createdAt }
  view: 'chat',      // 'chat' | 'onboarding' | 'account' | 'history'
  onboardStep: 'welcome',
  connectTab: 'anthropic',
  afterConnect: 'chat',
  modelCache: {},
  lastSel: null,
  treeOpen: true,     // the branch tree list; folds to the path bar while you read a branch
  attachments: [],  // images waiting to be sent: { mime, data(base64), w, h, name }
  handledPending: new Set(),
};

/* ================= storage ================= */

function convKey(url) {
  try { const u = new URL(url); return u.origin + u.pathname.replace(/\/+$/, ''); } catch { return url || 'unknown'; }
}

/** URLs of a "new chat" screen; the site swaps in a real conversation URL after the first message. */
function isNewChatKey(key) {
  try {
    const u = new URL(key);
    const p = u.pathname.replace(/\/+$/, '');
    if (/(^|\.)claude\.ai$/.test(u.hostname)) return p === '' || p === '/new' || /^\/project\/[^/]+$/.test(p);
    if (/(^|\.)chatgpt\.com$|(^|\.)chat\.openai\.com$/.test(u.hostname)) return p === '' || /^\/g\/[^/]+(\/project)?$/.test(p);
    if (/(^|\.)gemini\.google\.com$/.test(u.hostname)) return /^(\/u\/\d+)?\/app$/.test(p) || p === '';
  } catch { /* not a URL */ }
  return false;
}

async function loadSettings() {
  const { settings, account } = await chrome.storage.local.get(['settings', 'account']);
  const s = structuredClone(DEFAULT_SETTINGS);
  if (settings) {
    Object.assign(s, settings);
    for (const k of ['keys', 'models', 'methods', 'connectedAt']) s[k] = { ...DEFAULT_SETTINGS[k], ...(settings[k] || {}) };
  }
  if (!PROVIDERS[s.provider]) s.provider = DEFAULT_SETTINGS.provider;
  // v1.2 briefly stopped sending the original chat by default; turn it back on once for everyone.
  if (settings && (settings.contextVersion || 0) < 2) { s.includeOriginal = true; s.contextVersion = 2; }
  state.settings = s;
  state.account = account || null;
}
const saveSettings = () => chrome.storage.local.set({ settings: state.settings });
const saveAccount = () => chrome.storage.local.set({ account: state.account });

async function loadTree(key, seed = {}) {
  const k = 'tree:' + key;
  const got = await chrome.storage.local.get(k);
  return got[k] || {
    key, url: seed.url || key, title: seed.title || '', site: seed.site || '',
    snapshot: null, nodes: {}, createdAt: Date.now(),
  };
}

/** Trees with branches are saved; empty ones are removed so history only lists real work. */
async function saveTree(tree, { touch = true } = {}) {
  if (!tree || !tree.key) return;
  if (!nodeCount(tree)) { await chrome.storage.local.remove('tree:' + tree.key); return; }
  if (touch || !tree.updatedAt) tree.updatedAt = Date.now();
  await chrome.storage.local.set({ ['tree:' + tree.key]: tree });
}

async function allTrees() {
  const all = await chrome.storage.local.get(null);
  return Object.entries(all).filter(([k]) => k.startsWith('tree:')).map(([, v]) => v);
}

/* ================= tree helpers ================= */

const childrenOf = (tree, id) =>
  Object.values(tree.nodes).filter((n) => n.parentId === id).sort((a, b) => a.createdAt - b.createdAt);

function pathTo(tree, id) {
  const out = [];
  let n = tree.nodes[id];
  while (n) { out.unshift(n); n = tree.nodes[n.parentId]; }
  return out; // top-level branch first, `id` last (root excluded)
}

function formatTranscript(snapshot, site, maxChars) {
  if (!snapshot || !snapshot.messages || !snapshot.messages.length) return '(The original conversation could not be captured.)';
  const name = { user: 'User', assistant: `Assistant (${site || 'AI'})`, page: 'Page content' };
  let text = snapshot.messages.map((m) => `### ${name[m.role] || m.role}\n${m.text}`).join('\n\n');
  if (text.length > maxChars) text = '[…earlier messages truncated…]\n\n' + text.slice(text.length - maxChars);
  return text;
}

function frameFirstQuestion(node, question) {
  const where = node.parentId === 'root' ? 'the original conversation' : 'your previous answer';
  return `I'm highlighting this passage from ${where}:\n\n"""\n${node.anchor}\n"""\n\n${question}`;
}

/**
 * Context for a node = every branch on its path (root to leaf), each starting from its highlight.
 * The original page chat is only included when the user turns that on.
 */
function buildRequest(tree, nodeId) {
  const path = pathTo(tree, nodeId);
  const s = state.settings;
  const parts = [
    'You are a helpful assistant. The user is exploring a side question (a "branch") about a passage they highlighted, and each branch can contain follow-up branches. Focus on the highlighted passage and the conversation in this branch.',
    'Reply like a normal chat answer: clear, well-structured Markdown (short paragraphs, **bold** for key terms, lists or numbered steps when helpful, tables only for comparisons). Do not use decorative characters, emoji or ASCII art.',
    'Write all math in LaTeX: $...$ for inline math and $$...$$ on its own line for display equations. Never use \\( \\) or \\[ \\].',
  ];
  if (s.instructions) parts.push(`Additional instructions from the user:\n${s.instructions}`);
  if (s.includeOriginal) {
    const snapshot = path[0].snapshot || tree.snapshot;
    parts.push(`Here is the original conversation (with ${tree.site || 'another AI assistant'}) that the first highlight came from. Use it as background: you may summarize it or answer questions about it.\n<original_conversation>\n${formatTranscript(snapshot, tree.site, Number(s.maxContextChars) || 100000)}\n</original_conversation>`);
  }
  const system = parts.join('\n\n');

  const messages = [];
  for (const n of path) {
    n.messages.forEach((m, i) => {
      const content = i === 0 && m.role === 'user' ? frameFirstQuestion(n, m.content) : m.content;
      const prev = messages[messages.length - 1];
      // Merge same-role neighbours (e.g. a question whose answer was interrupted) so roles alternate.
      const images = m.images || [];
      if (prev && prev.role === m.role) { prev.content += '\n\n' + content; prev.images = [...prev.images, ...images]; }
      else messages.push({ role: m.role, content, images });
    });
  }
  return { system, messages };
}

/* ================= tab tracking ================= */

// Tab events arrive in bursts; run syncs one at a time so two can't interleave and mix up chats.
let syncChain = Promise.resolve();
function syncToActiveTab() {
  syncChain = syncChain.then(doSyncToActiveTab, doSyncToActiveTab);
  return syncChain;
}

async function doSyncToActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, windowId: state.windowId });
  if (!tab) return;
  const prev = { key: state.key, tree: state.tree, tabId: state.tab && state.tab.id };
  const key = convKey(tab.url);
  state.tab = tab;
  if (key === state.key && state.tree && state.tree.key === key) {
    // Sites rename the tab once a chat gets a title; keep history labels current.
    if (tab.title && tab.title !== state.tree.title && !/^(claude|chatgpt|gemini|google gemini|new chat)\b.{0,12}$/i.test(tab.title)) {
      state.tree.title = tab.title;
      saveTree(state.tree, { touch: false });
      // Only the header text changed: update it without redrawing the conversation (keeps any text selection).
      if (state.view === 'chat') $('convTitle').textContent = cleanTitle(tab.title);
    }
    return;
  }

  // Branches made on a "new chat" screen follow the chat once the site gives it its real URL.
  if (prev.tree && prev.tabId === tab.id && nodeCount(prev.tree) && isNewChatKey(prev.key) && !isNewChatKey(key)
      && new URL(prev.key).origin === new URL(key).origin) {
    const existing = await loadTree(key);
    if (!nodeCount(existing)) {
      await chrome.storage.local.remove('tree:' + prev.key);
      prev.tree.key = key;
      prev.tree.url = tab.url;
      state.key = key;
      state.tree = prev.tree;
      await saveTree(state.tree);
      render();
      return;
    }
  }

  state.key = key;
  state.tree = await loadTree(key, { url: tab.url, title: tab.title });
  state.current = state.tree.lastOpen && state.tree.nodes[state.tree.lastOpen] ? state.tree.lastOpen : 'root';
  state.treeOpen = state.current === 'root';
  state.draft = null;
  render();
  if (!state.tree.snapshot) refreshSnapshot({ quiet: true });
}

async function refreshSnapshot({ quiet = false } = {}) {
  if (!state.tab) return null;
  const tree = state.tree;
  try {
    const tab = await chrome.tabs.get(state.tab.id);
    if (convKey(tab.url) !== tree.key) throw new Error('open this chat in the current tab first');
    const [res] = await chrome.scripting.executeScript({ target: { tabId: state.tab.id }, func: scrapeChat });
    const r = res && res.result;
    if (!r) throw new Error('No result');
    if (state.tree !== tree) return null; // tab changed meanwhile
    applyScrape(tree, r);
    await saveTree(tree);
    if (state.view === 'chat') render();
    return tree.snapshot;
  } catch (e) {
    if (!quiet) showError(`Couldn't read this page (${e.message}). Right-click a selection on the page instead — that grants access.`);
    return null;
  }
}

function applyScrape(tree, r) {
  if (!r || !r.messages) return;
  tree.snapshot = { messages: r.messages, capturedAt: Date.now() };
  tree.site = r.site || tree.site;
  tree.title = r.title || tree.title;
}

/* ================= pending branches from the page context menu ================= */

async function handlePending(p) {
  if (!p || state.handledPending.has(p.id) || Date.now() - p.ts > 60000) return;
  state.handledPending.add(p.id);
  await chrome.storage.session.remove('pending');
  if (p.tabId) chrome.action.setBadgeText({ tabId: p.tabId, text: '' }).catch(() => {});

  const key = convKey(p.url);
  if (key !== state.key) {
    state.key = key;
    state.tree = await loadTree(key, { url: p.url, title: p.title });
    state.tab = (await chrome.tabs.get(p.tabId).catch(() => null)) || state.tab;
  }
  if (p.scrape && p.scrape.error) showError(`Couldn't read the chat transcript: ${p.scrape.error}. The branch will only see your highlight.`);
  applyScrape(state.tree, p.scrape);
  if (!p.selection) { render(); return; }

  startDraft('root', p.selection);
  const preset = p.action !== 'ask' && PRESETS[p.action];
  if (!connectedProviders(state.settings).length) {
    if (preset) $('input').value = preset.prompt;
    openOnboarding(state.account ? 'connect' : 'welcome');
    return;
  }
  if (preset) send(preset.prompt);
}

function startDraft(parentId, anchor) {
  state.treeOpen = false;
  state.draft = { parentId, anchor: anchor.trim() };
  state.current = parentId;
  state.view = 'chat';
  hideBranchBtn();
  render();
  $('input').focus();
}

/* ================= sending ================= */

async function send(text, opts = {}) {
  text = (text || '').trim();
  const images = opts.images ? opts.images.slice() : state.attachments.slice();
  if ((!text && !images.length) || state.streaming) return false;
  clearError();
  if (!hasCredential(state.settings, state.settings.provider)) {
    const connected = connectedProviders(state.settings);
    if (connected.length) { state.settings.provider = connected[0]; await saveSettings(); }
    else { $('input').value = text; openOnboarding(state.account ? 'connect' : 'welcome'); return; }
  }

  const tree = state.tree;
  let node;
  let createdNow = false;
  if (state.draft) {
    createdNow = true;
    const d = state.draft;
    node = {
      id: uid(), parentId: d.parentId, anchor: d.anchor, messages: [], createdAt: Date.now(),
      snapshot: d.parentId === 'root' ? tree.snapshot : undefined, // freeze the chat as it was when branching
    };
    tree.nodes[node.id] = node;
    state.draft = null;
    state.current = node.id;
    tree.lastOpen = node.id;
  } else {
    node = tree.nodes[state.current];
  }
  if (!node) return false;

  node.messages.push(images.length ? { role: 'user', content: text, images, ts: Date.now() } : { role: 'user', content: text, ts: Date.now() });
  if (!opts.images) { state.attachments = []; renderAttachments(); }
  if (!opts.fromEdit) $('input').value = '';
  autosize();
  await saveTree(tree);

  const { system, messages } = buildRequest(tree, node.id);
  const controller = new AbortController();
  state.streaming = { tree, nodeId: node.id, text: '', controller, status: '', sources: [] };
  render();

  const s = state.settings;
  const webSearch = !!s.webSearch && !!SEARCH_SUPPORTED[s.provider];
  let ok = false;
  try {
    for await (const chunk of streamChat(s, { system, messages, signal: controller.signal, webSearch })) {
      if (typeof chunk === 'string') { state.streaming.text += chunk; state.streaming.status = ''; }
      else if (chunk.type === 'status') state.streaming.status = chunk.text;
      else if (chunk.type === 'sources') state.streaming.sources = chunk.items;
      scheduleStreamPaint();
    }
    const reply = { role: 'assistant', content: state.streaming.text || '(empty response)', ts: Date.now(), model: `${s.provider}:${s.models[s.provider]}` };
    if (state.streaming.sources.length) reply.sources = state.streaming.sources;
    if (webSearch) reply.searched = true;
    node.messages.push(reply);
    ok = true;
  } catch (e) {
    const partial = state.streaming.text;
    if (e.name === 'AbortError' && partial) {
      node.messages.push({ role: 'assistant', content: partial + '\n\n*[stopped]*', ts: Date.now(), ...(state.streaming.sources.length ? { sources: state.streaming.sources } : {}) });
      ok = true;
    } else {
      node.messages.pop(); // drop the unanswered question so it can be retried
      if (createdNow && !node.messages.length) {
        delete tree.nodes[node.id];
        if (state.tree === tree) { state.draft = { parentId: node.parentId, anchor: node.anchor }; state.current = node.parentId; }
      }
      if (state.tree === tree && !opts.fromEdit) { $('input').value = text; state.attachments = images; renderAttachments(); }
      if (e.code === 'NO_KEY') openOnboarding('connect');
      else if (e.name !== 'AbortError') showError(friendlyError(s.provider, e), e.status === 401 || e.status === 403, e.message);
    }
  } finally {
    state.streaming = null;
    await saveTree(tree);
    if (state.view === 'chat') render();
    syncToActiveTab(); // catch up if the user switched tabs while the answer streamed
  }
  return ok;
}

/** Edit one of your earlier questions in a branch: everything after it is replaced by a new answer. */
async function editAndResend(nodeId, idx, text) {
  const tree = state.tree;
  const node = tree && tree.nodes[nodeId];
  if (!node || state.streaming || !node.messages[idx]) return;
  const backup = node.messages.slice();
  const old = node.messages[idx];
  node.messages = node.messages.slice(0, idx);
  state.draft = null;
  state.current = nodeId;
  const ok = await send(text, { images: old.images || [], fromEdit: true });
  if (!ok && state.tree === tree) {
    node.messages = backup; // put the conversation back exactly as it was
    await saveTree(tree);
    render();
  }
}

let paintQueued = false;
function scheduleStreamPaint() {
  if (paintQueued) return;
  paintQueued = true;
  requestAnimationFrame(() => {
    paintQueued = false;
    const body = document.querySelector('.msg.streaming .body');
    const st = document.querySelector('.msg.streaming .stream-status');
    if (st && state.streaming) { st.textContent = state.streaming.status; st.hidden = !state.streaming.status; }
    const src = document.querySelector('.msg.streaming .sources-slot');
    if (src && state.streaming) src.replaceChildren(...sourcesEls(state.streaming.sources));
    if (body && state.streaming) {
      const main = $('main');
      const atBottom = main.scrollHeight - main.scrollTop - main.clientHeight < 60;
      body.innerHTML = renderMarkdown(state.streaming.text);
      if (atBottom) main.scrollTop = main.scrollHeight;
    }
  });
}

/* ================= rendering: frame ================= */

function render() {
  const tree = state.tree;
  const s = state.settings;
  const inChat = state.view === 'chat';

  $('convSite').textContent = inChat ? (tree && (tree.site || siteFromUrl(tree.url))) || 'Branch Chat' : 'Branch Chat';
  $('convTitle').textContent = inChat ? cleanTitle((tree && tree.title) || (state.tab && state.tab.title) || '') :
    { onboarding: 'Account setup', account: 'Your account', history: 'Your branched chats' }[state.view];

  const connected = connectedProviders(s);
  const sel = $('providerSelect');
  sel.hidden = !connected.length || state.view === 'onboarding';
  sel.replaceChildren(...connected.map((k) => el('option', { value: k }, PROVIDERS[k].short)));
  if (connected.includes(s.provider)) sel.value = s.provider;

  const acc = $('accountBtn');
  acc.textContent = state.account && state.account.name ? state.account.name.trim()[0].toUpperCase() : '?';
  acc.classList.toggle('active', state.view === 'account');
  $('historyBtn').classList.toggle('active', state.view === 'history');
  $('topBar').hidden = state.view === 'onboarding';

  $('treeSection').hidden = !inChat;
  if (inChat) { renderTree(); renderTreeBar(); }

  const main = $('main');
  main.replaceChildren();
  $('composer').hidden = true;

  if (state.view === 'onboarding') return renderOnboarding(main);
  if (state.view === 'account') return renderAccount(main);
  if (state.view === 'history') return renderHistory(main);

  if (!tree) { main.append(el('div', { class: 'empty' }, 'Loading…')); return; }
  if (state.draft) renderDraft(main);
  else if (state.current === 'root' || !tree.nodes[state.current]) { state.current = 'root'; renderRoot(main); }
  else renderNode(main, tree.nodes[state.current]);
  renderComposer();
}

/* ================= rendering: chat ================= */

function renderTree() {
  const tree = state.tree;
  const box = $('tree');
  box.replaceChildren();
  if (!tree) return;

  const rowFor = (id, label, title) => {
    const active = !state.draft && state.current === id;
    const row = el('div', { class: 'trow' + (active ? ' active' : ''), title, onclick: () => go(id) },
      el('span', { class: 'label' }, label));
    if (id !== 'root') {
      row.append(el('button', { class: 'del', title: 'Delete branch', onclick: (e) => { e.stopPropagation(); deleteNode(id); } }, '×'));
    }
    return row;
  };
  const build = (id) => {
    const kids = childrenOf(tree, id);
    if (!kids.length) return null;
    return el('ul', {}, kids.map((k) => el('li', { class: 'tnode' },
      rowFor(k.id, plainText(k.anchor), plainText(k.anchor)), build(k.id))));
  };
  box.append(el('ul', { class: 'tnode root' }, el('li', { class: 'tnode' },
    rowFor('root', 'Original chat', 'Original chat'), build('root'))));
}

const anchorLabel = (text, cls = '') => el('span', { class: 'mathlabel ' + cls, title: plainText(text) }, plainText(text));

/** The one-line bar above the tree: current path (clickable) + memory chip; the tree list folds away under it. */
function renderTreeBar() {
  const tree = state.tree;
  const open = state.treeOpen;
  $('tree').classList.toggle('collapsed', !open);
  $('treeCaret').textContent = open ? '▾' : '▸';
  $('treeToggle').setAttribute('aria-expanded', String(open));
  const n = nodeCount(tree);
  $('treeCount').textContent = n ? String(n) : '';
  const path = state.draft ? crumbs(state.draft.parentId, 'New branch') : crumbs(state.current);
  $('treePath').replaceChildren(path);
  $('memChip').replaceChildren(...[memoryChip()].filter(Boolean));
}

function crumbs(nodeId, extraLabel) {
  const tree = state.tree;
  const parts = [nodeId === 'root' && !extraLabel
    ? el('span', { class: 'here' }, 'Original chat')
    : el('button', { onclick: () => go('root') }, 'Original chat')];
  const path = nodeId === 'root' ? [] : pathTo(tree, nodeId);
  path.forEach((n, i) => {
    parts.push(el('span', { class: 'sep' }, '/'));
    if (i === path.length - 1 && !extraLabel) parts.push(anchorLabel(n.anchor, 'here'));
    else parts.push(el('button', { onclick: () => go(n.id) }, anchorLabel(n.anchor)));
  });
  if (extraLabel) parts.push(el('span', { class: 'sep' }, '/'), el('span', { class: 'here' }, extraLabel));
  return el('div', { class: 'crumbs' }, parts);
}

const ICON_COPY = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>';

const ICON_EDIT = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>';

function sourcesEls(items) {
  if (!items || !items.length) return [];
  return [el('div', { class: 'sources' },
    el('span', { class: 'sources-label' }, 'Sources'),
    items.slice(0, 8).map((it, i) => {
      let host = '';
      try { host = new URL(it.url).hostname.replace(/^www\./, ''); } catch { /* ignore */ }
      return el('a', { class: 'source', href: it.url, target: '_blank', rel: 'noopener noreferrer', title: it.url },
        el('span', { class: 'source-n' }, String(i + 1)), el('span', { class: 'source-t' }, it.title || host || it.url));
    }))];
}

function msgEl(m, nodeId, extraClass = '', idx = -1) {
  const content = m.content ?? m.text;
  if (m.role === 'user') {
    const imgs = (m.images || []).map((img) => el('img', {
      class: 'msg-img', src: imgSrc(img), alt: img.name || 'image', onclick: () => openLightbox(imgSrc(img)),
    }));
    const wrap = el('div', { class: `msg user ${extraClass}`, 'data-node': nodeId },
      imgs.length ? el('div', { class: 'msg-imgs' }, imgs) : null,
      content ? el('div', { class: 'bubble selectable' }, content) : null);
    if (idx >= 0 && !state.streaming) {
      const editBtn = el('button', { class: 'act', title: 'Edit and resend', html: ICON_EDIT });
      editBtn.addEventListener('click', () => startEdit(wrap, nodeId, idx, content || ''));
      wrap.append(el('div', { class: 'actions-row user-actions' }, editBtn));
    }
    return wrap;
  }
  const copyBtn = el('button', { class: 'act', title: 'Copy', html: ICON_COPY });
  copyBtn.addEventListener('click', () => {
    navigator.clipboard.writeText(content);
    copyBtn.textContent = 'Copied';
    setTimeout(() => { copyBtn.innerHTML = ICON_COPY; }, 1200);
  });
  const streaming = extraClass.includes('streaming');
  return el('div', { class: `msg assistant ${extraClass}`, 'data-node': nodeId },
    streaming ? el('div', { class: 'stream-status', hidden: !(state.streaming && state.streaming.status) }, (state.streaming && state.streaming.status) || '') : null,
    el('div', { class: 'body prose selectable', html: renderMarkdown(content) }),
    streaming ? el('div', { class: 'sources-slot' }, sourcesEls(state.streaming && state.streaming.sources)) : sourcesEls(m.sources),
    streaming ? null : el('div', { class: 'actions-row' }, copyBtn, m.searched ? el('span', { class: 'searched' }, 'Searched the web') : null));
}

function startEdit(wrap, nodeId, idx, text) {
  const ta = el('textarea', { class: 'edit-box', rows: 2 });
  ta.value = text;
  const later = state.tree.nodes[nodeId].messages.length - idx - 1;
  const save = el('button', { class: 'btn primary-sm' }, 'Save & send');
  const cancel = el('button', { class: 'btn' }, 'Cancel');
  const box = el('div', { class: 'edit-wrap' }, ta,
    el('div', { class: 'edit-actions' },
      later > 0 ? el('span', { class: 'hint' }, 'Replaces the answer below') : el('span'),
      el('div', { class: 'edit-btns' }, cancel, save)));
  cancel.addEventListener('click', () => render());
  save.addEventListener('click', () => { const v = ta.value.trim(); if (v) editAndResend(nodeId, idx, v); });
  ta.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); save.click(); }
    if (e.key === 'Escape') render();
  });
  wrap.replaceChildren(...[...wrap.querySelectorAll('.msg-imgs')], box);
  ta.focus();
  ta.setSelectionRange(ta.value.length, ta.value.length);
  ta.style.height = Math.min(ta.scrollHeight + 2, 200) + 'px';
}

function quoteEl(text) {
  return el('div', { class: 'quote prose', html: renderMarkdown(text) });
}

/** Re-read the chat page and give the chosen top-level branches (and everything under them) that newer copy. */
async function updateMemory(topIds, btn) {
  if (state.streaming) return;
  const tree = state.tree;
  const label = btn && btn.lastChild.textContent;
  if (btn) { btn.disabled = true; btn.lastChild.textContent = 'Updating…'; btn.classList.add('busy'); }
  const snap = await refreshSnapshot();
  if (snap && state.tree === tree) {
    for (const id of topIds) if (tree.nodes[id]) tree.nodes[id].snapshot = snap;
    await saveTree(tree);
    state.memoryFlash = 'Updated just now ✓';
    render();
    setTimeout(() => { state.memoryFlash = null; if (state.view === 'chat') render(); }, 2500);
  } else if (btn) {
    btn.disabled = false; btn.classList.remove('busy'); btn.lastChild.textContent = label.replace('Updating…', 'Update');
  }
}

const ICON_REFRESH = '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-2.6-6.4L21 8"/><path d="M21 3v5h-5"/></svg>';

const agoShort = (ts) => {
  const m = Math.round((Date.now() - ts) / 60000);
  if (m < 1) return 'just now';
  if (m < 60) return `${m}m ago`;
  if (m < 1440) return `${Math.round(m / 60)}h ago`;
  return `${Math.round(m / 1440)}d ago`;
};

/** Small "↻ Updated 12m ago" chip: shows how fresh a branch's copy of the original chat is; click to refresh. */
function memoryChip() {
  const tree = state.tree;
  if (!tree || !state.settings.includeOriginal || state.view !== 'chat') return null;
  let topIds = [];
  let snap = null;
  if (!state.draft && state.current !== 'root' && tree.nodes[state.current]) {
    const top = pathTo(tree, state.current)[0];
    topIds = [top.id];
    snap = top.snapshot || tree.snapshot;
  } else if (!state.draft && state.current === 'root') {
    const kids = childrenOf(tree, 'root');
    if (!kids.length) return null;
    topIds = kids.map((k) => k.id);
    snap = kids.map((k) => k.snapshot).filter(Boolean).sort((a, b) => a.capturedAt - b.capturedAt)[0];
  } else {
    return null;
  }
  const label = state.memoryFlash || (snap ? `Updated ${agoShort(snap.capturedAt)}` : 'Update');
  const scope = topIds.length > 1 ? 'all branches in this chat' : 'this branch';
  const btn = el('button', {
    class: 'mem-chip' + (state.memoryFlash ? ' done' : ''),
    title: (snap ? `Remembers the original chat as of ${new Date(snap.capturedAt).toLocaleString()} (${snap.messages.length} messages).\n` : '')
      + `Click to re-read the chat page so ${scope} know about newer messages.`,
  });
  btn.innerHTML = ICON_REFRESH + '<span></span>';
  btn.lastChild.textContent = label;
  btn.addEventListener('click', () => updateMemory(topIds, btn));
  return btn;
}

function renderRoot(main) {
  const kids = childrenOf(state.tree, 'root');
  if (!kids.length) {
    main.append(el('div', { class: 'empty' },
      el('div', { class: 'empty-title' }, 'Branch off any part of a chat'),
      el('p', {}, 'Highlight text in ChatGPT, Claude or Gemini, right-click, and choose ', el('b', {}, 'Branch chat'), '.'),
      el('p', {}, 'Highlight text in a branch answer to branch again.')));
    return;
  }
  main.append(el('div', { class: 'section-title' }, 'Branches in this chat'));
  renderChildren(main, 'root', true);
}

function renderNode(main, node) {
  const tree = state.tree;
  main.append(quoteEl(node.anchor));
  node.messages.forEach((m, i) => main.append(msgEl(m, node.id, '', i)));
  if (state.streaming && state.streaming.nodeId === node.id && state.streaming.tree === tree) {
    main.append(msgEl({ role: 'assistant', content: state.streaming.text || ' ' }, node.id, 'streaming'));
  }
  renderChildren(main, node.id);
  requestAnimationFrame(() => { main.scrollTop = main.scrollHeight; });
}

function renderDraft(main) {
  const d = state.draft;
  main.append(quoteEl(d.anchor));
}

function renderChildren(main, id, bare = false) {
  const kids = childrenOf(state.tree, id);
  if (!kids.length) return;
  main.append(el('div', { class: bare ? 'children bare' : 'children' },
    bare ? null : el('div', { class: 'section-title' }, 'Branches from here'),
    kids.map((k) => el('button', { class: 'child-link', onclick: () => go(k.id) }, anchorLabel(k.anchor)))));
}

function renderComposer() {
  const show = !!state.draft || (state.current !== 'root' && state.tree && state.tree.nodes[state.current]);
  $('composer').hidden = !show;
  const chips = $('chips');
  chips.replaceChildren();
  if (state.draft && !state.streaming) {
    for (const p of Object.values(PRESETS)) chips.append(el('button', { class: 'chip', onclick: () => send(p.prompt) }, p.label));
  }
  $('input').placeholder = state.draft ? 'Ask about the highlighted text…' : 'Ask a follow-up in this branch…';
  renderAttachments();
  const sb = $('searchBtn');
  const can = !!SEARCH_SUPPORTED[state.settings.provider];
  const on = can && !!state.settings.webSearch;
  sb.disabled = !can;
  sb.classList.toggle('on', on);
  sb.setAttribute('aria-pressed', String(on));
  sb.title = !can ? 'Web search isn’t available for custom servers' : on ? 'Search the web: on (each search costs a little extra)' : 'Search the web: off';
  const btn = $('sendBtn');
  btn.classList.toggle('stop', !!state.streaming);
  btn.textContent = state.streaming ? '■' : '↑';
  btn.title = state.streaming ? 'Stop' : 'Send (Enter)';
}

/* ================= onboarding / account setup ================= */

function openOnboarding(step = 'welcome', afterConnect = 'chat') {
  state.view = 'onboarding';
  state.onboardStep = step;
  state.afterConnect = afterConnect;
  clearError();
  render();
}

async function finishConnect(provider, key, method) {
  const s = state.settings;
  let ids = [];
  try { ids = await listModels(provider, key, s.baseUrl); }
  catch (e) {
    throw new Error(friendlyError(provider, e));
  }
  state.modelCache[provider] = ids;
  s.keys[provider] = key;
  if (provider === 'compatible') s.compatibleConnected = true;
  s.methods[provider] = method;
  s.connectedAt[provider] = Date.now();
  s.models[provider] = pickDefaultModel(provider, ids, s.models[provider] || PROVIDERS[provider].defaultModel);
  s.provider = provider;
  await saveSettings();
}

function renderOnboarding(main) {
  const wrap = el('div', { class: 'onb' });
  main.append(wrap);
  const status = el('div', { class: 'status', role: 'status' });
  const setStatus = (msg, kind = '') => { status.textContent = msg; status.className = 'status ' + kind; };
  const stepDots = el('div', { class: 'steps' },
    ['welcome', 'connect', 'done'].map((s) => el('span', { class: 'stepdot' + (s === state.onboardStep ? ' on' : '') })));

  if (state.onboardStep === 'welcome') {
    const name = el('input', { placeholder: 'e.g. Thomas', value: (state.account && state.account.name) || '', maxlength: 40 });
    const next = async () => {
      const v = name.value.trim();
      if (!v) { setStatus('Enter a name to continue.', 'bad'); name.focus(); return; }
      state.account = { ...(state.account || { createdAt: Date.now() }), name: v };
      await saveAccount();
      state.onboardStep = connectedProviders(state.settings).length ? 'done' : 'connect';
      render();
    };
    name.addEventListener('keydown', (e) => { if (e.key === 'Enter') next(); });
    wrap.append(stepDots,
      el('div', { class: 'logo' }, '⑂'),
      el('h2', {}, 'Welcome to Branch Chat'),
      el('p', { class: 'lead' }, 'Set up your account to start branching off your AI chats.'),
      el('label', {}, 'What should we call you?'), name,
      el('button', { class: 'wide primary-btn', onclick: next }, 'Continue'),
      status,
      el('p', { class: 'fine' }, 'Your account, connections and branches are saved in this browser.'));
    setTimeout(() => name.focus(), 0);
    return;
  }

  if (state.onboardStep === 'connect') {
    // --- Sign in with OpenRouter ---
    const signBtn = el('button', { class: 'wide primary-btn' }, 'Sign in with OpenRouter');
    signBtn.addEventListener('click', async () => {
      signBtn.disabled = true;
      setStatus('A sign-in window is open — log in and click Authorize…');
      try {
        const key = await signInWithOpenRouter();
        setStatus('Signed in. Checking your account…');
        await finishConnect('openrouter', key, 'signin');
        state.onboardStep = 'done';
        render();
      } catch (e) {
        setStatus(e.message, 'bad');
        signBtn.disabled = false;
      }
    });
    const orCard = el('div', { class: 'card recommended' },
      el('div', { class: 'card-head' }, el('strong', {}, 'Sign in — easiest'), el('span', { class: 'badge' }, 'Recommended')),
      el('p', {}, 'Log in to OpenRouter (Google, GitHub or email) and approve. No keys to copy. One account gives you Claude, GPT, Gemini and more.'),
      signBtn);

    // --- Paste an API key ---
    const tabs = ['anthropic', 'openai', 'gemini', 'compatible'];
    const t = tabs.includes(state.connectTab) ? state.connectTab : 'anthropic';
    const info = PROVIDERS[t];
    const seg = el('div', { class: 'seg' }, tabs.map((k) => el('button', {
      class: k === t ? 'on' : '', onclick: () => { state.connectTab = k; render(); },
    }, PROVIDERS[k].short)));

    const keyIn = el('input', { type: 'password', placeholder: t === 'compatible' ? 'API key (optional)' : 'Paste your API key', autocomplete: 'off' });
    const baseIn = t === 'compatible' ? el('input', { value: state.settings.baseUrl, placeholder: 'http://localhost:11434/v1' }) : null;
    const connectBtn = el('button', { class: 'wide' }, `Connect ${info.short}`);
    connectBtn.addEventListener('click', async () => {
      const key = keyIn.value.replace(/\s+/g, '');
      if (!key && t !== 'compatible') { setStatus('Paste your key first.', 'bad'); keyIn.focus(); return; }
      const problem = key && keyFormatProblem(t, key);
      if (problem) { setStatus(problem, 'bad'); keyIn.focus(); return; }
      connectBtn.disabled = true;
      setStatus('Checking your key…');
      try {
        if (baseIn) {
          state.settings.baseUrl = baseIn.value.trim() || DEFAULT_SETTINGS.baseUrl;
          // Ask for access to the server (helps if it lacks CORS headers) without blocking the connect step.
          chrome.permissions.request({ origins: [new URL(state.settings.baseUrl).origin + '/*'] }).catch(() => {});
        }
        await finishConnect(t, key, 'key');
        state.onboardStep = 'done';
        render();
      } catch (e) {
        setStatus(e.message, 'bad');
        connectBtn.disabled = false;
      }
    });
    keyIn.addEventListener('keydown', (e) => { if (e.key === 'Enter') connectBtn.click(); });

    const howTo = t === 'compatible'
      ? el('ol', { class: 'howto' }, el('li', {}, 'Run a local server such as Ollama or LM Studio.'), el('li', {}, 'Enter its OpenAI-compatible URL (ends in /v1).'))
      : el('ol', { class: 'howto' },
        el('li', {}, el('a', { href: info.keyUrl, target: '_blank', rel: 'noopener' }, `Open the ${info.short} key page ↗`), ' and sign in.'),
        el('li', {}, t === 'gemini' ? 'Click “Create API key”.' : 'Click “Create key” and copy it.'),
        el('li', {}, 'Paste it below.'));

    const keyCard = el('div', { class: 'card' },
      el('div', { class: 'card-head' }, el('strong', {}, 'Or use an API key')),
      seg, howTo, baseIn ? el('label', {}, 'Server URL') : null, baseIn, keyIn, connectBtn,
      t === 'anthropic' || t === 'openai' ? el('p', { class: 'fine' }, 'Needs billing set up on that site (pay-as-you-go).') : null,
      t === 'gemini' ? el('p', { class: 'fine' }, 'Google AI Studio includes a free tier.') : null);

    const back = state.account && connectedProviders(state.settings).length
      ? el('button', { class: 'link', onclick: () => { state.view = state.afterConnect; render(); } }, '‹ Back')
      : el('button', { class: 'link', onclick: () => { state.onboardStep = 'welcome'; render(); } }, '‹ Back');

    wrap.append(stepDots,
      el('h2', {}, state.account ? `Connect your AI, ${state.account.name}` : 'Connect your AI'),
      el('p', { class: 'lead' }, 'Choose how Branch Chat answers your branch questions.'),
      orCard, keyCard, status,
      el('details', { class: 'why' },
        el('summary', {}, 'Why can’t I just sign in to ChatGPT, Claude or Gemini?'),
        el('p', {}, 'Those chat subscriptions don’t let other apps use them. Branch Chat uses each company’s API instead, which is billed separately (usually a few cents per question). Your branches stay connected to your chats either way.')),
      back);
    return;
  }

  // done
  const p = state.settings.provider;
  wrap.append(stepDots,
    el('div', { class: 'logo ok' }, '✓'),
    el('h2', {}, `You’re all set${state.account ? ', ' + state.account.name : ''}!`),
    el('p', { class: 'lead' }, `Connected to ${PROVIDERS[p].short} · model `, el('code', {}, state.settings.models[p])),
    el('ol', { class: 'howto' },
      el('li', {}, 'Open any chat in ChatGPT, Claude or Gemini.'),
      el('li', {}, 'Highlight text → right-click → ', el('b', {}, 'Branch chat'), '.'),
      el('li', {}, 'Your branches are saved with that chat. Come back to it anytime.')),
    el('button', { class: 'wide primary-btn', onclick: () => { state.view = state.afterConnect === 'account' ? 'account' : 'chat'; render(); } },
      state.draft ? 'Back to my branch' : 'Start branching'));
}

/* ================= account ================= */

function renderAccount(main) {
  const s = state.settings;
  const a = state.account || { name: '', createdAt: Date.now() };
  const wrap = el('div', { class: 'settings' });
  main.append(wrap);
  const status = el('span', { class: 'hint' });
  const flash = (m) => { status.textContent = m; setTimeout(() => { if (status.textContent === m) status.textContent = ''; }, 3000); };

  wrap.append(el('div', { class: 'crumbs' }, el('button', { onclick: () => { state.view = 'chat'; render(); } }, '‹ Back to chat')));

  // Profile
  const nameIn = el('input', { value: a.name, maxlength: 40 });
  nameIn.addEventListener('change', async () => {
    state.account = { ...a, name: nameIn.value.trim() || a.name };
    await saveAccount();
    $('accountBtn').textContent = state.account.name[0].toUpperCase();
    flash('Name saved ✓');
  });
  wrap.append(el('div', { class: 'profile' },
    el('div', { class: 'avatar big' }, (a.name || '?')[0].toUpperCase()),
    el('div', { class: 'grow' }, el('label', {}, 'Name'), nameIn,
      el('div', { class: 'hint' }, `Member since ${new Date(a.createdAt).toLocaleDateString()}`))));

  // Connections
  const connected = connectedProviders(s);
  const conn = el('fieldset', {}, el('legend', {}, 'Connected AI'));
  if (!connected.length) conn.append(el('p', { class: 'hint' }, 'Nothing connected yet.'));
  for (const p of connected) {
    const isActive = s.provider === p;
    const how = s.methods[p] === 'signin' ? 'Signed in' : p === 'compatible' ? s.baseUrl : `API key ${maskKey(s.keys[p])}`;
    conn.append(el('div', { class: 'conn-row' + (isActive ? ' active' : '') },
      el('div', { class: 'grow' }, el('strong', {}, PROVIDERS[p].short), isActive ? el('span', { class: 'badge' }, 'In use') : null,
        el('div', { class: 'hint' }, how)),
      !isActive ? el('button', { class: 'btn', onclick: async () => { s.provider = p; await saveSettings(); render(); } }, 'Use') : null,
      el('button', { class: 'btn', onclick: async () => {
        try { await listModels(p, s.keys[p], s.baseUrl); flash(`${PROVIDERS[p].short} works ✓`); }
        catch (e) { flash(friendlyError(p, e)); }
      } }, 'Test'),
      el('button', { class: 'btn danger', onclick: async () => {
        if (!confirm(`Disconnect ${PROVIDERS[p].short}?`)) return;
        s.keys[p] = '';
        if (p === 'compatible') s.compatibleConnected = false;
        delete s.methods[p];
        if (s.provider === p) s.provider = connectedProviders(s)[0] || DEFAULT_SETTINGS.provider;
        await saveSettings();
        render();
      } }, 'Disconnect')));
  }
  conn.append(el('button', { class: 'btn', onclick: () => openOnboarding('connect', 'account') }, '+ Connect another'));
  wrap.append(conn);

  // Model for active provider
  if (connected.includes(s.provider)) {
    const p = s.provider;
    const listId = 'models-' + p;
    const modelIn = el('input', { value: s.models[p], list: listId, placeholder: PROVIDERS[p].defaultModel });
    const dl = el('datalist', { id: listId }, (state.modelCache[p] || []).map((m) => el('option', { value: m })));
    modelIn.addEventListener('change', async () => { s.models[p] = modelIn.value.trim() || PROVIDERS[p].defaultModel; await saveSettings(); flash('Model saved ✓'); });
    const loadBtn = el('button', { class: 'btn', onclick: async () => {
      try {
        state.modelCache[p] = await listModels(p, s.keys[p], s.baseUrl);
        dl.replaceChildren(...state.modelCache[p].map((m) => el('option', { value: m })));
        flash(`${state.modelCache[p].length} models available — click the box to pick`);
      } catch (e) { flash(e.message); }
    } }, '↻ Load list');
    wrap.append(el('fieldset', {}, el('legend', {}, `Model (${PROVIDERS[p].short})`),
      el('div', { class: 'row' }, el('div', {}, modelIn, dl), el('div', { class: 'shrink' }, loadBtn)),
      p === 'openrouter' ? el('p', { class: 'hint' }, 'openrouter/auto picks a model for you. Try anthropic/…, openai/… or google/… models from the list.') : null));
  }

  // Advanced
  const maxCtx = el('input', { type: 'number', min: 2000, step: 1000, value: s.maxContextChars });
  const maxTok = el('input', { type: 'number', min: 256, step: 256, value: s.maxTokens });
  const instr = el('textarea', { rows: 3, placeholder: 'e.g. Answer in bullet points. I am a beginner.' });
  instr.value = s.instructions || '';
  const saveAdv = async () => {
    s.maxContextChars = Number(maxCtx.value) || DEFAULT_SETTINGS.maxContextChars;
    s.maxTokens = Number(maxTok.value) || DEFAULT_SETTINGS.maxTokens;
    s.instructions = instr.value;
    await saveSettings();
    flash('Saved ✓');
  };
  const incl = el('input', { type: 'checkbox' });
  incl.checked = !!s.includeOriginal;
  incl.addEventListener('change', async () => { s.includeOriginal = incl.checked; await saveSettings(); flash('Saved ✓'); });
  [maxCtx, maxTok, instr].forEach((x) => x.addEventListener('change', saveAdv));
  wrap.append(el('details', { class: 'adv' }, el('summary', {}, 'Answer preferences'),
    el('label', {}, 'Extra instructions for every branch'), instr,
    el('label', { class: 'check' }, incl, ' Remember the original chat ', el('span', { class: 'hint' }, '(recommended — off sends only your highlights and branches)')),
    el('div', { class: 'row' },
      el('div', {}, el('label', {}, 'Max chat context (chars)'), maxCtx),
      el('div', {}, el('label', {}, 'Max answer tokens'), maxTok))));

  // Data
  const dataInfo = el('p', { class: 'hint' }, 'Counting…');
  allTrees().then((ts) => {
    const n = ts.reduce((a2, t) => a2 + nodeCount(t), 0);
    dataInfo.textContent = `${ts.length} chat${ts.length === 1 ? '' : 's'} with ${n} branch${n === 1 ? '' : 'es'} saved in this browser.`;
  });
  const fileIn = el('input', { type: 'file', accept: 'application/json', hidden: true });
  fileIn.addEventListener('change', async () => {
    const f = fileIn.files[0];
    if (!f) return;
    try { const n = await importBackup(JSON.parse(await f.text())); flash(`Imported ${n} chat(s) ✓`); render(); }
    catch (e) { flash('Import failed: ' + e.message); }
  });
  wrap.append(el('fieldset', {}, el('legend', {}, 'Your branches'), dataInfo,
    el('div', { class: 'actions' },
      el('button', { class: 'btn', onclick: () => { state.view = 'history'; render(); } }, 'View all'),
      el('button', { class: 'btn', onclick: exportBackup }, 'Export backup'),
      el('button', { class: 'btn', onclick: () => fileIn.click() }, 'Import backup'), fileIn)));

  wrap.append(el('div', { class: 'actions' }, status));
  wrap.append(el('div', { class: 'actions' },
    el('button', { class: 'btn danger', onclick: async () => {
      if (!confirm('Sign out? This removes your account and AI connections from this browser. Your branches stay saved.')) return;
      state.account = null;
      state.settings = structuredClone(DEFAULT_SETTINGS);
      await chrome.storage.local.remove(['account', 'settings']);
      openOnboarding('welcome');
    } }, 'Sign out')));
  wrap.append(el('p', { class: 'note' }, 'Keys are stored only in this browser and are sent only to the AI service they belong to.'));
}

async function exportBackup() {
  const trees = await allTrees();
  const data = { app: 'branch-chat', version: 1, exportedAt: new Date().toISOString(), account: state.account ? { name: state.account.name } : null, trees };
  const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
  el('a', { href: url, download: `branch-chat-backup-${new Date().toISOString().slice(0, 10)}.json` }).click();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

async function importBackup(data) {
  if (!data || !Array.isArray(data.trees)) throw new Error('Not a Branch Chat backup file');
  let n = 0;
  for (const t of data.trees) {
    if (!t || !t.key || !t.nodes) continue;
    const existing = await loadTree(t.key, t);
    existing.nodes = { ...t.nodes, ...existing.nodes }; // keep local copies on conflict
    existing.title = existing.title || t.title;
    existing.site = existing.site || t.site;
    existing.snapshot = existing.snapshot || t.snapshot;
    await saveTree(existing);
    n++;
  }
  if (state.key) state.tree = await loadTree(state.key, { url: state.tab && state.tab.url });
  return n;
}

/* ================= history ================= */

function renderHistory(main) {
  const wrap = el('div', { class: 'history' });
  main.append(wrap);
  const search = el('input', { class: 'search', placeholder: 'Search your chats and branches…' });
  const list = el('div');
  wrap.append(el('div', { class: 'crumbs' }, el('button', { onclick: () => { state.view = 'chat'; render(); } }, '‹ Back to chat')),
    el('h3', {}, 'Your branched chats'), search, list);

  allTrees().then((trees) => {
    trees.sort((x, y) => (y.updatedAt || 0) - (x.updatedAt || 0));
    const draw = () => {
      const q = search.value.trim().toLowerCase();
      const shown = trees.filter((t) => !q || [t.title, t.site, ...Object.values(t.nodes).map((n) => n.anchor)].join(' ').toLowerCase().includes(q));
      list.replaceChildren();
      if (!shown.length) {
        list.append(el('div', { class: 'empty' }, trees.length ? 'No matches.' : 'No branches yet. Highlight text in a chat and right-click → Branch chat.'));
        return;
      }
      for (const t of shown) {
        const tops = childrenOf(t, 'root');
        list.append(el('div', { class: 'hist-item' + (t.key === state.key ? ' current' : '') },
          el('div', { class: 'grow', onclick: () => openChat(t) },
            el('div', {}, el('span', { class: 'site-chip' }, t.site || 'Web'), ' ', el('strong', {}, short(cleanTitle(t.title) || t.url, 60))),
            el('div', { class: 'hint' }, `${nodeCount(t)} branch${nodeCount(t) === 1 ? '' : 'es'} · ${ago(t.updatedAt || t.createdAt)}`),
            el('div', { class: 'hist-anchors' }, tops.slice(0, 3).map((n) => anchorLabel(n.anchor)))),
          el('button', { class: 'del', title: 'Delete all branches for this chat', onclick: async (e) => {
            e.stopPropagation();
            const at = trees.indexOf(t);
            await chrome.storage.local.remove('tree:' + t.key);
            trees.splice(at, 1);
            if (t.key === state.key) { state.tree = await loadTree(t.key, t); state.current = 'root'; }
            draw();
            showToast(`Deleted “${short(cleanTitle(t.title) || 'chat', 32)}”`, async () => {
              await chrome.storage.local.set({ ['tree:' + t.key]: t });
              trees.splice(at, 0, t);
              if (t.key === state.key) { state.tree = t; }
              if (state.view === 'history') draw(); else render();
            });
          } }, '×')));
      }
    };
    search.addEventListener('input', draw);
    draw();
  });
}

async function openChat(t) {
  state.view = 'chat';
  if (t.key === state.key) { render(); return; }
  if (state.tab) await chrome.tabs.update(state.tab.id, { url: t.url });
  else await chrome.tabs.create({ url: t.url });
  // tabs.onUpdated will load this chat's branches once the URL changes.
}

/* ================= actions ================= */

function go(id) {
  state.treeOpen = id === 'root';
  state.draft = null;
  state.memoryFlash = null;
  state.view = 'chat';
  state.current = id;
  if (state.tree) { state.tree.lastOpen = id; if (nodeCount(state.tree)) chrome.storage.local.set({ ['tree:' + state.tree.key]: state.tree }); }
  clearError();
  render();
}

async function deleteNode(id) {
  const tree = state.tree;
  const doomed = [id];
  for (let i = 0; i < doomed.length; i++) for (const c of childrenOf(tree, doomed[i])) doomed.push(c.id);
  if (state.streaming && doomed.includes(state.streaming.nodeId)) state.streaming.controller.abort();
  const removed = doomed.map((d) => tree.nodes[d]);
  const node = tree.nodes[id];
  const prevCurrent = state.current;
  doomed.forEach((d) => delete tree.nodes[d]);
  if (doomed.includes(state.current)) state.current = node ? node.parentId : 'root';
  await saveTree(tree);
  render();
  const subs = doomed.length - 1;
  showToast(subs ? `Branch and ${subs} sub-branch${subs > 1 ? 'es' : ''} deleted` : 'Branch deleted', async () => {
    for (const n of removed) tree.nodes[n.id] = n;
    await saveTree(tree);
    if (state.tree === tree) { state.current = prevCurrent; render(); }
  });
}

let toastTimer;
let toastUndo = null;
/** Bottom toast with an Undo button; the action is final once it disappears. */
function showToast(msg, undo) {
  clearTimeout(toastTimer);
  toastUndo = undo || null;
  $('toastMsg').textContent = msg;
  $('toastUndo').hidden = !undo;
  $('toast').hidden = false;
  toastTimer = setTimeout(hideToast, 7000);
}
function hideToast() { $('toast').hidden = true; toastUndo = null; }
$('toastUndo').addEventListener('click', async () => {
  const fn = toastUndo;
  hideToast();
  if (fn) await fn();
});

let errTimer;
function showError(msg, withAccountLink = false, details = '') {
  const e = $('error');
  e.replaceChildren(msg);
  e.title = details || '';
  if (withAccountLink) e.append(' ', el('button', { class: 'link', onclick: () => openOnboarding('connect', 'chat') }, 'Reconnect'));
  e.hidden = false;
  clearTimeout(errTimer);
  errTimer = setTimeout(clearError, 15000);
}
function clearError() { $('error').hidden = true; }

function autosize() {
  const t = $('input');
  t.style.height = 'auto';
  t.style.height = Math.min(t.scrollHeight, 160) + 'px';
}

/* ================= selection → branch (inside the panel) ================= */

function selectionInPanel() {
  const sel = window.getSelection();
  const text = sel ? sel.toString().trim() : '';
  if (!text || !sel.rangeCount) return null;
  const range = sel.getRangeAt(0);
  const node = range.commonAncestorContainer.nodeType === 1 ? range.commonAncestorContainer : range.commonAncestorContainer.parentElement;
  const msg = node && node.closest('.msg[data-node]');
  if (!msg) return null;
  const clean = scrapeChat().selectionText || text;
  return { nodeId: msg.dataset.node, text: clean, rect: range.getBoundingClientRect() };
}

function hideBranchBtn() { $('branchBtn').hidden = true; }

document.addEventListener('mouseup', () => setTimeout(() => {
  const s = state.view === 'chat' && selectionInPanel();
  const btn = $('branchBtn');
  if (!s || state.streaming) { hideBranchBtn(); return; }
  state.lastSel = s;
  btn.hidden = false;
  const w = btn.offsetWidth;
  btn.style.left = Math.max(6, Math.min(window.innerWidth - w - 6, s.rect.left + s.rect.width / 2 - w / 2)) + 'px';
  btn.style.top = Math.max(6, s.rect.top - 34) + 'px';
}, 0));
document.addEventListener('contextmenu', () => { const s = selectionInPanel(); if (s) state.lastSel = s; });
$('main').addEventListener('scroll', hideBranchBtn);
$('branchBtn').addEventListener('mousedown', (e) => e.preventDefault()); // keep the selection
$('branchBtn').addEventListener('click', () => {
  const s = state.lastSel;
  if (!s) return;
  window.getSelection().removeAllRanges();
  startDraft(s.nodeId, s.text);
});

chrome.runtime.onMessage.addListener((msg) => {
  if (msg && msg.type === 'panel-branch' && state.lastSel) {
    startDraft(state.lastSel.nodeId, state.lastSel.text);
    if (msg.action !== 'ask' && PRESETS[msg.action]) send(PRESETS[msg.action].prompt);
  }
});

/* ================= images ================= */

const MAX_IMAGES = 6;
const MAX_SIDE = 1568; // largest side the models use without downscaling
const imgSrc = (img) => `data:${img.mime};base64,${img.data}`;

async function fileToImage(file) {
  const bmp = await createImageBitmap(file);
  const scale = Math.min(1, MAX_SIDE / Math.max(bmp.width, bmp.height));
  const w = Math.max(1, Math.round(bmp.width * scale));
  const h = Math.max(1, Math.round(bmp.height * scale));
  const canvas = new OffscreenCanvas(w, h);
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#ffffff'; // flatten transparency (JPEG has none)
  ctx.fillRect(0, 0, w, h);
  ctx.drawImage(bmp, 0, 0, w, h);
  bmp.close();
  const blob = await canvas.convertToBlob({ type: 'image/jpeg', quality: 0.88 });
  const buf = new Uint8Array(await blob.arrayBuffer());
  let bin = '';
  for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode(...buf.subarray(i, i + 0x8000));
  return { mime: 'image/jpeg', data: btoa(bin), w, h, name: file.name || 'image' };
}

async function addImages(files) {
  const list = [...files].filter((f) => f && f.type && f.type.startsWith('image/'));
  if (!list.length) return;
  if ($('composer').hidden) { showError('Open a branch (or start one) to attach images.'); return; }
  for (const f of list) {
    if (state.attachments.length >= MAX_IMAGES) { showError(`Up to ${MAX_IMAGES} images per message.`); break; }
    try { state.attachments.push(await fileToImage(f)); }
    catch (e) { showError(`Couldn't read ${f.name || 'that image'}: ${e.message}`); }
  }
  renderAttachments();
  $('input').focus();
}

function renderAttachments() {
  const box = $('attachments');
  box.replaceChildren(...state.attachments.map((img, i) => el('div', { class: 'thumb' },
    el('img', { src: imgSrc(img), alt: img.name, onclick: () => openLightbox(imgSrc(img)) }),
    el('button', { class: 'thumb-x', title: 'Remove', onclick: () => { state.attachments.splice(i, 1); renderAttachments(); } }, '×'))));
  box.hidden = !state.attachments.length;
}

function openLightbox(src) {
  const lb = el('div', { class: 'lightbox', onclick: () => lb.remove() }, el('img', { src }));
  document.body.append(lb);
}

$('attachBtn').addEventListener('click', () => $('fileInput').click());
$('fileInput').addEventListener('change', (e) => { addImages(e.target.files); e.target.value = ''; });
$('input').addEventListener('paste', (e) => {
  const files = [...(e.clipboardData ? e.clipboardData.files : [])];
  if (files.some((f) => f.type.startsWith('image/'))) { e.preventDefault(); addImages(files); }
});
document.addEventListener('dragover', (e) => { if ([...e.dataTransfer.types].includes('Files')) { e.preventDefault(); document.body.classList.add('dragging'); } });
document.addEventListener('dragleave', (e) => { if (!e.relatedTarget) document.body.classList.remove('dragging'); });
document.addEventListener('drop', (e) => {
  document.body.classList.remove('dragging');
  if (e.dataTransfer && e.dataTransfer.files.length) { e.preventDefault(); addImages(e.dataTransfer.files); }
});
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') document.querySelectorAll('.lightbox').forEach((l) => l.remove()); });

$('searchBtn').addEventListener('click', async () => {
  state.settings.webSearch = !state.settings.webSearch;
  await saveSettings();
  renderComposer();
});
$('main').addEventListener('click', (e) => {
  const b = e.target.closest('.code-copy');
  if (!b) return;
  const code = b.closest('.codeblock').querySelector('code').innerText;
  navigator.clipboard.writeText(code).then(() => {
    b.textContent = 'Copied';
    setTimeout(() => { b.textContent = 'Copy'; }, 1200);
  }).catch(() => { b.textContent = 'Copy failed'; });
});

/* ================= wiring ================= */

$('sendBtn').addEventListener('click', () => {
  if (state.streaming) state.streaming.controller.abort();
  else send($('input').value);
});
$('input').addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); if (!state.streaming) send($('input').value); }
});
$('input').addEventListener('input', autosize);
$('accountBtn').addEventListener('click', () => {
  if (!state.account) { openOnboarding('welcome'); return; }
  state.view = state.view === 'account' ? 'chat' : 'account';
  render();
});
$('historyBtn').addEventListener('click', () => { state.view = state.view === 'history' ? 'chat' : 'history'; render(); });
$('providerSelect').addEventListener('change', async (e) => { state.settings.provider = e.target.value; await saveSettings(); render(); });
$('treeToggle').addEventListener('click', () => { state.treeOpen = !state.treeOpen; renderTreeBar(); });

chrome.tabs.onActivated.addListener((info) => { if (info.windowId === state.windowId && !state.streaming) syncToActiveTab(); });
chrome.tabs.onUpdated.addListener((tabId, change, tab) => {
  if (!state.streaming && tab.active && tab.windowId === state.windowId && (change.url || change.title || change.status === 'complete')) syncToActiveTab();
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'session' && changes.pending && changes.pending.newValue) handlePending(changes.pending.newValue);
  if (area === 'local' && (changes.settings || changes.account) && state.view === 'chat') loadSettings().then(render);
});

(async function init() {
  // ?window=<id> lets tests drive a panel that isn't docked in the window it tracks.
  const forced = Number(new URLSearchParams(location.search).get('window'));
  state.windowId = forced || (await chrome.windows.getCurrent()).id;
  await loadSettings();
  await syncToActiveTab();
  const { pending } = await chrome.storage.session.get('pending');
  if (pending) await handlePending(pending);
  if (state.view !== 'onboarding' && (!state.account || !connectedProviders(state.settings).length)) {
    openOnboarding(state.account ? 'connect' : 'welcome');
  }
})();

// Exposed for tests/debugging.
globalThis.__branchChat = { state, buildRequest, pathTo, render, finishConnect };
