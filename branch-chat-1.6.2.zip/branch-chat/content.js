// Shows a small "Branch" button next to text you select on ChatGPT, Claude or Gemini.
(() => {
  const alive = () => { try { return !!chrome.runtime && !!chrome.runtime.id; } catch { return false; } };

  // Run once per page. After the extension is updated, the old copy stops working, so a new copy takes over.
  const prev = window.__branchChatButton;
  if (prev && prev.alive && prev.alive()) return;
  if (prev && prev.remove) prev.remove();

  let host = null;
  let lastText = '';
  window.__branchChatButton = { alive, remove: () => { if (host) host.remove(); host = null; } };

  function build() {
    host = document.createElement('div');
    host.style.cssText = 'position:fixed;z-index:2147483647;top:0;left:0;display:none;';
    const root = host.attachShadow({ mode: 'closed' });
    root.innerHTML = `
      <style>
        .bar { display: flex; gap: 2px; padding: 3px; border-radius: 999px; background: #1f1f1f; border: 1px solid #383838;
               box-shadow: 0 6px 20px rgba(0,0,0,.35); font: 600 12.5px/1 ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif; }
        button { all: unset; cursor: pointer; color: #e6e6e6; padding: 6px 10px; border-radius: 999px; display: inline-flex; align-items: center; gap: 6px; white-space: nowrap; }
        button:hover { background: #303030; }
        button:focus-visible { outline: 2px solid #e6e6e6; outline-offset: 1px; }
        .primary { background: #e6e6e6; color: #1f1f1f; }
        .primary:hover { background: #ffffff; }
        svg { flex: none; }
      </style>
      <div class="bar" role="toolbar" aria-label="Branch Chat">
        <button class="primary" data-action="ask" title="Start a branch about this text and ask your own question">
          <svg viewBox="0 0 512 512" width="13" height="13" aria-hidden="true"><g stroke="currentColor" stroke-width="40" fill="none"><line x1="256" y1="120" x2="140" y2="300"/><line x1="256" y1="120" x2="372" y2="300"/><line x1="372" y1="300" x2="372" y2="420"/><circle cx="256" cy="120" r="60"/><circle cx="140" cy="300" r="50"/><circle cx="372" cy="300" r="50"/><circle cx="372" cy="420" r="50"/></g></svg>
          Branch from here
        </button>
        <button data-action="explain" title="Branch and explain this concisely">Explain</button>
      </div>`;
    root.querySelectorAll('button').forEach((b) => {
      b.addEventListener('mousedown', (e) => e.preventDefault()); // keep the page selection
      b.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const action = b.dataset.action;
        hide();
        if (!alive()) return;
        try { chrome.runtime.sendMessage({ type: 'branch-from-page', action, selectionText: lastText }); } catch { /* extension was reloaded */ }
      });
    });
    document.documentElement.appendChild(host);
  }

  function hide() { if (host) host.style.display = 'none'; }

  function selectionInfo() {
    const sel = window.getSelection();
    if (!sel || sel.isCollapsed || !sel.rangeCount) return null;
    const text = sel.toString().trim();
    if (!text) return null;
    const n = sel.anchorNode;
    const el = n && (n.nodeType === 1 ? n : n.parentElement);
    // Don't pop up while typing in the chat's own message box.
    if (el && el.closest('input, textarea, [contenteditable="true"], [contenteditable=""], [role="textbox"]')) return null;
    const range = sel.getRangeAt(0);
    const rects = range.getClientRects();
    const r = rects.length ? rects[rects.length - 1] : range.getBoundingClientRect();
    if (!r || (!r.width && !r.height)) return null;
    return { text, r };
  }

  function show() {
    if (!alive()) { hide(); return; }
    const info = selectionInfo();
    if (!info) { hide(); return; }
    lastText = info.text;
    if (!host) build();
    host.style.display = 'block';
    const w = host.offsetWidth || 150;
    const h = host.offsetHeight || 34;
    let left = info.r.right - w / 2;
    let top = info.r.bottom + 8; // below the selection, clear of the sites' own popups above it
    if (top + h > window.innerHeight - 8) top = info.r.top - h - 8;
    left = Math.max(8, Math.min(window.innerWidth - w - 8, left));
    host.style.left = `${left}px`;
    host.style.top = `${Math.max(8, top)}px`;
  }

  document.addEventListener('mouseup', (e) => {
    if (host && e.composedPath().includes(host)) return;
    setTimeout(show, 10);
  }, true);
  document.addEventListener('mousedown', (e) => {
    if (host && !e.composedPath().includes(host)) hide();
  }, true);
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') hide(); }, true);
  document.addEventListener('keyup', (e) => { if (e.shiftKey && e.key.startsWith('Arrow')) show(); }, true);
  window.addEventListener('scroll', hide, true);
  window.addEventListener('resize', hide);
})();
