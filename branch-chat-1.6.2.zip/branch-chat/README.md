# Branch Chat (Chrome extension)

Highlight a word, phrase or sentence in **ChatGPT, Claude or Gemini**, right-click, and open a side conversation ("branch") about it, answered by the model you choose. Each branch remembers the original chat and **only the branches on its own path**:

```
(1) original chat
 └─ 2  "question about a phrase in (1)"
     ├─ 3  "phrase from 2's answer"
     │   └─ 4   → sees 1 → 2 → 3 → 4
     └─ 5       → sees 1 → 2 → 5   (never 3 or 4)
```

## Install (developer mode)

1. Open `chrome://extensions` and turn on **Developer mode** (top right).
2. Click **Load unpacked** and select this `branch-chat` folder.
3. Pin the extension and click its icon to open the side panel.

## Account setup (first run)

The side panel walks you through it:

1. **Your name.** Creates your Branch Chat account in this browser.
2. **Connect your AI.** Pick one:
   - **Sign in with OpenRouter (recommended).** Log in with Google, GitHub or email and click Authorize. No key to copy. One account covers Claude, GPT, Gemini and other models.
   - **Use an API key** for Claude, ChatGPT (OpenAI) or Gemini. The setup links to each provider's key page; paste the key and the extension checks it.
   - **Custom.** Any OpenAI-compatible server, such as Ollama or LM Studio.
3. Done. Manage everything later from the round avatar button: rename yourself, connect more AIs, switch which one is in use, pick a model, export or import backups, or sign out.

Why there's no "sign in to ChatGPT/Claude/Gemini": those chat subscriptions can't be used by other apps, so the extension uses each company's API, which is billed separately.

## Use

- **From the chat page:** highlight text → right-click → **Branch chat on "…"** → *Explain this concisely* or *Ask my own question…*. The side panel opens and the answer streams in.
- **Faster:** on ChatGPT, Claude and Gemini a small **Branch from here / Explain** button appears under any text you select. You can also press **Alt+Shift+K** (change it at `chrome://extensions/shortcuts`).
- **Keep going:** type follow-ups in the branch; ask as many questions as you need.
- **Branch from a branch:** highlight text in any answer in the side panel → click **⑂ Branch from selection**.
- **Navigate:** the bar at the top shows where you are (Original chat / branch / sub-branch). Click ▸ to open the full tree; it folds away automatically while you read a branch. Hover a branch and click × to delete it — a toast lets you **Undo**.
- **Search the web:** turn on the **Search** toggle next to the message box. Answers then use live web results and list their sources as links underneath. Works with Claude, ChatGPT (via OpenAI's Responses API), Gemini (Google Search) and OpenRouter; each search costs a little extra on your API bill. Not available for custom servers.
- **Edit and resend:** hover one of your questions and click the pencil to change it. The answer after it is replaced; if the resend fails, the branch is put back as it was.
- **Code:** code blocks are syntax-highlighted (bundled highlight.js) and have a Copy button.
- **Images:** add pictures to any branch message with the image button, by pasting (⌘V / Ctrl+V), or by dragging them into the panel. Up to 6 per message; they're resized to 1568 px and saved with the branch, so later questions in that branch still see them. Claude, ChatGPT, Gemini and OpenRouter vision models all accept them.
- **History (🕘):** every chat you've branched, across ChatGPT, Claude and Gemini, with search. Click one to reopen it with its branches.

## Saving

- Branches are saved automatically, per chat, after every message. Leave a chat and come back, switch tabs, close the panel, or restart Chrome: the branches are still there, and it reopens the branch you were on.
- Branches started on a "new chat" page (for example `claude.ai/new`) move with the chat when the site gives it its real URL.
- Everything is stored in this browser (`chrome.storage.local`, with no size cap). Removing the extension deletes it, so use **Account → Export backup** to keep a copy, and **Import backup** to restore it or move it to another computer.

## How the memory works

- Each branch remembers the original chat plus its own path: the highlighted passage, then every branch from the top of the tree down to this one. Sibling branches never see each other.
- The original chat is read from the page when you start a branch and saved with that branch. If you keep chatting on the page afterwards, press **Update** at the top of a branch to give it (and its sub-branches) the latest version of the chat, or **Update all branches** on the Original chat view. It's sent to the AI as background but not shown in the panel. Turn it off under **Account → Answer preferences → Remember the original chat** to send only your highlights and branches.
- Equations you highlight are captured as LaTeX (`$…$` inline, `$$…$$` display), so the model sees real math instead of scrambled symbols.

## Math

Answers render LaTeX with a bundled copy of [KaTeX](https://katex.org) (MIT license, in `vendor/katex`). The model is asked to write math as `$…$` and `$$…$$`; `\(…\)` and `\[…\]` also work. Dollar amounts such as `$5` are left alone.

## Files

| File | Purpose |
|---|---|
| `manifest.json` | MV3 manifest: context menu, side panel, permissions |
| `background.js` | Builds the right-click menu, opens the panel, reads the transcript, hands the request to the panel |
| `lib/scrape.js` | Transcript reader for ChatGPT, Claude and Gemini, with a whole-page fallback |
| `lib/providers.js` | Streaming clients for OpenRouter, Anthropic, OpenAI, Gemini and OpenAI-compatible APIs |
| `lib/auth.js` | Sign in with OpenRouter (OAuth PKCE), key checks, model lists |
| `lib/markdown.js` | Small, HTML-escaping Markdown renderer with LaTeX math and tables |
| `vendor/katex/` | KaTeX 0.16.11 (math rendering) |
| `vendor/hljs/` | highlight.js 11.9.0 (code highlighting, BSD-3-Clause) |
| `sidepanel.*` | Tree UI, branch chat, context building, settings |

## Notes and limits

- **Selectors break.** These AI sites change their HTML often. If a transcript comes back empty, update the selectors in `lib/scrape.js`. On other sites the extension falls back to the page's visible text.
- **Model names:** after you connect, the extension loads the provider's current model list, and you can change the model under Account → Model.
- **API keys** stay in your browser and go only to the provider you pick. Calls are billed to your API account, separately from any ChatGPT, Claude or Gemini subscription.
- The extension does not post anything into the original chat; branches live only in the side panel.
