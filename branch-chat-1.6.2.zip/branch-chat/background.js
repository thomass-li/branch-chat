import { scrapeChat } from './lib/scrape.js';

const MENU = [
  ['explain', 'Explain this concisely'],
  ['ask', 'Ask my own question…'],
];

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({ id: 'branch', title: 'Branch chat on "%s"', contexts: ['selection'] });
    for (const [id, title] of MENU) {
      chrome.contextMenus.create({ id, parentId: 'branch', title, contexts: ['selection'] });
    }
  });
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
  injectIntoOpenChats();
});

const CHAT_URLS = ['https://chatgpt.com/*', 'https://chat.openai.com/*', 'https://claude.ai/*', 'https://gemini.google.com/*'];

/** Chrome only adds content scripts to pages loaded after install/update; add the Branch button to chats already open. */
async function injectIntoOpenChats() {
  const tabs = await chrome.tabs.query({ url: CHAT_URLS }).catch(() => []);
  for (const t of tabs) {
    chrome.scripting.executeScript({ target: { tabId: t.id }, files: ['content.js'] }).catch(() => {});
  }
}

chrome.contextMenus.onClicked.addListener((info, tab) => {
  const action = String(info.menuItemId);

  // Right-click inside the side panel itself: branch from the panel's own messages.
  if (info.pageUrl && info.pageUrl.startsWith(chrome.runtime.getURL(''))) {
    chrome.runtime.sendMessage({ type: 'panel-branch', action, selection: info.selectionText }).catch(() => {});
    return;
  }
  if (!tab || tab.id == null) return;

  // Must run synchronously inside the user gesture, before any await.
  chrome.sidePanel.open({ windowId: tab.windowId }).catch((e) => console.warn('sidePanel.open', e));
  queueBranch(info, tab, action);
});

async function queueBranch(info, tab, action) {
  let scrape;
  try {
    const [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: scrapeChat });
    scrape = res && res.result;
  } catch (e) {
    scrape = { error: String((e && e.message) || e), messages: [] };
  }
  const selection = ((scrape && scrape.selectionText) || info.selectionText || '').trim();
  await chrome.storage.session.set({
    pending: {
      id: crypto.randomUUID(),
      action,
      selection,
      scrape,
      tabId: tab.id,
      url: tab.url,
      title: tab.title,
      ts: Date.now(),
    },
  });
}

// Floating "Branch" button on the chat page (content.js).
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (!msg || msg.type !== 'branch-from-page' || !sender.tab) return;
  chrome.sidePanel.open({ windowId: sender.tab.windowId }).catch(() => {
    // If Chrome won't open the panel from here, flag the toolbar icon: the branch waits until it's clicked.
    chrome.action.setBadgeText({ tabId: sender.tab.id, text: '1' }).catch(() => {});
    chrome.action.setBadgeBackgroundColor({ color: '#e6e6e6' }).catch(() => {});
  });
  queueBranch({ selectionText: msg.selectionText || '' }, sender.tab, msg.action === 'ask' ? 'ask' : 'explain');
});

// Keyboard shortcut (Alt+Shift+K by default; change it at chrome://extensions/shortcuts).
chrome.commands.onCommand.addListener((command, tab) => {
  if (command !== 'branch-selection' || !tab || tab.id == null) return;
  chrome.sidePanel.open({ windowId: tab.windowId }).catch((e) => console.warn('sidePanel.open', e));
  queueBranch({ selectionText: '' }, tab, 'ask');
});
